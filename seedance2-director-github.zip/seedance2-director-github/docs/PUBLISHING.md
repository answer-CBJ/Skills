# 上传至GitHub

目标仓库：<https://github.com/answer-CBJ/Skills>。

本目录是一套可放在仓库根目录的文件。GitHub没有要求所有项目使用同一种目录结构；这里采用README、MIT许可证、独立技能目录、测试证据和自动检查工作流的常见组织方式。

## GitHub Desktop方式

1. 克隆目标仓库到本地。
2. 仓库为空时，将本包的内容复制到仓库根目录。已有内容时先检查重名文件，不覆盖已有README、LICENSE或其他项目；可将本项目作为子目录加入，并相应调整安装路径与工作流的工作目录。
3. 确认 `.github/`、`.gitignore`、`.gitattributes`、`.editorconfig` 等隐藏项目也在变更列表中。
4. 运行README中的本地检查，查看差异，提交并推送。

上传的是解压后的文件，不是只把ZIP放进仓库；这样GitHub才能展示README、比较修改并执行工作流。

## 首次发布核对

- README中的实际技能路径与仓库布局一致。
- 根目录MIT许可证与已有仓库许可策略一致；已有其他许可时不要直接替换。
- 原PDF、个人本机路径、临时目录与访问凭证没有进入提交。
- 只记录实际完成的测试；GitHub Actions首次运行需要在推送后确认结果。

本包没有预设发布版本标签，也没有徽章宣称远端检查已经通过。

参考：[GitHub README说明](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/about-readmes)、[许可证说明](https://docs.github.com/en/repositories/managing-your-repositorys-settings-and-features/customizing-your-repository/licensing-a-repository)、[工作流语法](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax)。
