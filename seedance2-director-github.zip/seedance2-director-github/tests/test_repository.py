"""Verify that publication validation catches concrete packaging errors."""

from pathlib import Path
import importlib.util
import shutil
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('repo_validator', ROOT / 'scripts/validate_repo.py')
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)


class PackagingFailures(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.repo = Path(self.temporary.name) / 'repository'
        shutil.copytree(ROOT, self.repo, ignore=shutil.ignore_patterns('.git', '__pycache__'))

    def test_current_repository_is_valid(self):
        self.assertEqual(validator.validate(self.repo), [])

    def test_missing_reference_is_reported(self):
        (self.repo / 'skills/seedance2-director/references/input-analysis.md').unlink()
        errors = validator.validate(self.repo)
        self.assertTrue(any('Broken local link' in e for e in errors))

    def test_missing_original_case_is_reported(self):
        (self.repo / 'tests/blackbox/raw/T04.md').unlink()
        self.assertTrue(any('Missing case evidence' in e for e in validator.validate(self.repo)))

    def test_wrong_installation_name_is_reported(self):
        path = self.repo / 'skills/seedance2-director/SKILL.md'
        path.write_text(path.read_text(encoding='utf-8').replace('name: seedance2-director', 'name: unrelated-skill', 1), encoding='utf-8')
        self.assertTrue(any('Skill name' in e for e in validator.validate(self.repo)))

    def test_personal_machine_path_is_reported(self):
        path = self.repo / 'examples/personal-path.md'
        path.write_text('C:' + chr(92) + 'Users' + chr(92) + 'example' + chr(92) + 'private.txt', encoding='utf-8')
        self.assertTrue(any('Personal absolute path' in e for e in validator.validate(self.repo)))


if __name__ == '__main__':
    unittest.main()
