---
name: Feature request / 功能建议
about: 提出具体创作场景和所需行为
title: "[Feature] "
---

## 使用场景

## 当前遇到的问题

## 希望增加的行为

## 可公开的示例输入和期望输出
