"""Validate this repository using only the Python standard library.

This checks the project's two-field scalar frontmatter, not arbitrary YAML.
It never invokes an LLM or video service.
"""

from pathlib import Path
import json
import re
import sys
from urllib.parse import unquote, urlsplit


ROOT = Path(__file__).resolve().parents[1]
SKILL = Path('skills/seedance2-director')
TEXT_TYPES = {'.md', '.txt', '.json', '.py', '.yml', '.yaml'}


def validate(root: Path) -> list[str]:
    root = root.resolve()
    errors = []
    required = [
        'README.md', 'LICENSE', 'NOTICE.md', 'CONTRIBUTING.md',
        '.github/workflows/validate.yml', 'docs/TESTING.md',
        str(SKILL / 'SKILL.md'), str(SKILL / 'agents/openai.yaml'),
        str(SKILL / 'references/input-analysis.md'),
        str(SKILL / 'references/prompt-grammar.md'),
        str(SKILL / 'references/examples.md'),
        str(SKILL / 'references/source-notes.md'),
    ]
    for name in required:
        if not (root / name).is_file():
            errors.append(f'Missing required file: {name}')

    entry = root / SKILL / 'SKILL.md'
    if entry.is_file():
        body = entry.read_text(encoding='utf-8')
        match = re.match(r'\A---\nname: ([a-z0-9-]+)\ndescription: ([^\n]+)\n---\n', body)
        if not match:
            errors.append('Unsupported or invalid skill frontmatter')
        else:
            if match[1] != 'seedance2-director':
                errors.append('Skill name must match its installation directory')
            if len(match[2]) > 1024 or any(c in match[2] for c in '<>'):
                errors.append('Skill description is invalid')

    for path in root.rglob('*'):
        if not path.is_file() or any(p in {'.git', '__pycache__', '.venv'} for p in path.relative_to(root).parts):
            continue
        if path.suffix not in TEXT_TYPES:
            continue
        try:
            text = path.read_text(encoding='utf-8')
        except UnicodeDecodeError:
            errors.append(f'Non-UTF-8 text: {path.relative_to(root)}')
            continue
        if re.search(r'[A-Za-z]:[\\/]+Users[\\/]', text):
            errors.append(f'Personal absolute path: {path.relative_to(root)}')
        if path.suffix == '.json':
            try:
                json.loads(text)
            except json.JSONDecodeError as exc:
                errors.append(f'Invalid JSON: {path.relative_to(root)}: {exc}')
        if path.suffix != '.md':
            continue
        for link in re.findall(r'\]\(([^)]+)\)', text):
            link = link.strip().strip('<>')
            parts = urlsplit(link)
            if parts.scheme or link.startswith('#'):
                continue
            dest = (path.parent / unquote(parts.path)).resolve()
            if not dest.is_relative_to(root) or not dest.exists():
                errors.append(f'Broken local link: {path.relative_to(root)} -> {link}')

    cases = root / 'tests/blackbox'
    try:
        criteria = json.loads((cases / 'criteria.json').read_text(encoding='utf-8'))
        results = json.loads((cases / 'results.json').read_text(encoding='utf-8'))
        ids = {f'T{i:02}' for i in range(1, 7)}
        if set(criteria) != ids or sum(map(len, criteria.values())) != 24:
            errors.append('Historical criteria inventory differs from the six-case/24-check record')
        records = results['results']
        if len(records) != 6 or {r['case'] for r in records} != ids:
            errors.append('Historical result inventory is incomplete')
        else:
            if sum(len(r['checks']) for r in records) != results['criteria']:
                errors.append('Historical check count does not match result summary')
            passed = sum(c['status'] == 'PASS' for r in records for c in r['checks'])
            if passed != results['criteria_passed']:
                errors.append('Historical passed-check summary is inconsistent')
            for r in records:
                if [c['criterion'] for c in r['checks']] != criteria[r['case']]:
                    errors.append(f'Criteria/result mismatch: {r["case"]}')
        for case in sorted(ids):
            for subdir, ext in [('inputs', '.txt'), ('raw', '.md')]:
                item = cases / subdir / (case + ext)
                if not item.is_file() or not item.read_text(encoding='utf-8').strip():
                    errors.append(f'Missing case evidence: {item.relative_to(root)}')
        fixture = root / results['image_observation']['fixture']
        if not fixture.is_file() or fixture.read_bytes()[:8] != b'\x89PNG\r\n\x1a\n':
            errors.append('Image fixture is missing or not a PNG')
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors.append(f'Invalid black-box evidence: {exc}')
    return errors


if __name__ == '__main__':
    problems = validate(ROOT)
    for problem in problems:
        print(f'ERROR: {problem}')
    if problems:
        sys.exit(1)
    print('Repository validation passed (files and historical evidence only).')
